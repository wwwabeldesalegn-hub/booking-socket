let ioRef;

function attachSocketHandlers(io) {
  ioRef = io;
  io.on('connection', (socket) => {
    // Register driver room based on auth token if provided
    try {
      const token = socket.handshake.auth?.token || socket.handshake.query?.token || socket.handshake.headers?.authorization?.replace(/^Bearer\s+/i, '');
      if (token) {
        const jwt = require('jsonwebtoken');
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'secret');
        const driverId = decoded && decoded.type === 'driver' ? String(decoded.id) : null;
        if (driverId) {
          socket.join(`driver:${driverId}`);
          socket.data = socket.data || {};
          socket.data.role = 'driver';
          socket.data.token = token;
        }
      }
    } catch (_) {}
    // Register event for both driver and passenger (role from token only)
    socket.on('register', async (data) => {
      try {
        const { authenticateSocket } = require('./socketAuth');
        const user = await authenticateSocket(socket);
        const role = user?.type || 'unknown';
        const location = (data && data.location) || {};
        if (role === 'driver') {
          if (!user || user.type !== 'driver') {
            return socket.emit('registerFailed', { message: 'Invalid or missing driver token' });
          }
          socket.join(`driver:${String(user.id)}`);
        }
        socket.data = { ...(socket.data || {}), role, location, token: (socket.handshake.auth?.token || socket.handshake.query?.token) };
        socket.emit('registerSuccess', { message: 'Registered successfully', socketId: socket.id, role, location });
      } catch (e) {
        socket.emit('registerFailed', { message: e.message });
      }
    });
    // Passenger creates a booking
    socket.on('createBooking', async (booking) => {
      try {
        const { Booking } = require('../models/bookingModels');
        const { Pricing } = require('../models/pricing');
        const geolib = require('geolib');
        const { authenticateSocket } = require('./socketAuth');

        const user = await authenticateSocket(socket);
        if (!user || user.type !== 'passenger') {
          return socket.emit('booking_error', { message: 'Unauthorized: passenger token required' });
        }

        const pickup = booking?.pickup || booking?.from || {};
        const dropoff = booking?.dropoff || booking?.to || {};
        if (pickup.latitude == null || pickup.longitude == null || dropoff.latitude == null || dropoff.longitude == null) {
          return socket.emit('booking_error', { message: 'pickup and dropoff with valid coordinates are required' });
        }

        // Estimate pricing immediately
        const distanceKm = geolib.getDistance(
          { latitude: pickup.latitude, longitude: pickup.longitude },
          { latitude: dropoff.latitude, longitude: dropoff.longitude }
        ) / 1000;
        const pricing = await Pricing.findOne({ vehicleType: booking?.vehicleType || 'mini', isActive: true }).sort({ updatedAt: -1 });
        const p = pricing || { baseFare: 2, perKm: 1, perMinute: 0, waitingPerMinute: 0, surgeMultiplier: 1 };
        const fareBreakdown = {
          base: p.baseFare,
          distanceCost: distanceKm * p.perKm,
          timeCost: 0,
          waitingCost: 0,
          surgeMultiplier: p.surgeMultiplier
        };
        const fareEstimated = (fareBreakdown.base + fareBreakdown.distanceCost + fareBreakdown.timeCost + fareBreakdown.waitingCost) * fareBreakdown.surgeMultiplier;

        const created = await Booking.create({
          passengerId: String(user.id),
          passengerName: user.name,
          passengerPhone: user.phone,
          vehicleType: booking?.vehicleType || 'mini',
          pickup: { latitude: pickup.latitude, longitude: pickup.longitude, address: booking?.pickup?.address },
          dropoff: { latitude: dropoff.latitude, longitude: dropoff.longitude, address: booking?.dropoff?.address },
          distanceKm,
          fareEstimated,
          fareBreakdown,
          status: 'requested'
        });

        const bookingPayload = {
          id: String(created._id),
          passengerId: created.passengerId,
          passenger: { id: String(user.id), name: user.name, phone: user.phone, email: user.email },
          vehicleType: created.vehicleType,
          pickup: created.pickup,
          dropoff: created.dropoff,
          distanceKm,
          fareEstimated,
          fareBreakdown,
          status: created.status,
          createdAt: created.createdAt,
          updatedAt: created.updatedAt
        };

        // Broadcast new booking targeted to nearby available drivers (by vehicle type)
        try {
          const { Driver } = require('../models/userModels');
          const geolib = require('geolib');
          const radiusKm = parseFloat(process.env.BROADCAST_RADIUS_KM || '5');
          const drivers = await Driver.find({ available: true, vehicleType: created.vehicleType }).lean();
          const within = drivers.filter(d => d.lastKnownLocation && (
            geolib.getDistance(
              { latitude: d.lastKnownLocation.latitude, longitude: d.lastKnownLocation.longitude },
              { latitude: created.pickup.latitude, longitude: created.pickup.longitude }
            ) / 1000
          ) <= radiusKm);
          within.forEach(d => {
            io.to(`driver:${String(d._id)}`).emit('newBooking', bookingPayload);
          });
          io.emit('bookingList', [bookingPayload]);
        } catch (_) {
          io.emit('newBooking', bookingPayload);
          io.emit('bookingList', [bookingPayload]);
        }
        socket.emit('booking_created', bookingPayload);
      } catch (e) {
        socket.emit('booking_error', { message: e.message });
      }
    });
    // Get nearby bookings for driver
    socket.on('getBookings', async () => {
      try {
        const { authenticateSocket } = require('./socketAuth');
        const { Booking } = require('../models/bookingModels');
        const geolib = require('geolib');
        const user = await authenticateSocket(socket);
        if (!user || user.type !== 'driver') {
          return socket.emit('bookingList', []);
        }
        const driverLoc = socket.data && socket.data.location;
        if (!driverLoc || driverLoc.lat == null || driverLoc.lng == null) {
          return socket.emit('bookingList', []);
        }
        const radiusKm = 2;
        const rows = await Booking.find({ status: 'requested' }).sort({ createdAt: -1 }).lean();
        const nearby = rows.filter(b => b.pickup && isFinite(b.pickup.latitude) && isFinite(b.pickup.longitude)).filter(b => {
          const dKm = geolib.getDistance(
            { latitude: driverLoc.lat, longitude: driverLoc.lng },
            { latitude: b.pickup.latitude, longitude: b.pickup.longitude }
          ) / 1000;
          return dKm <= radiusKm;
        }).map(b => ({
          id: String(b._id),
          passengerId: b.passengerId,
          vehicleType: b.vehicleType,
          pickup: b.pickup,
          dropoff: b.dropoff,
          status: b.status,
          createdAt: b.createdAt,
          updatedAt: b.updatedAt
        }));
        socket.emit('bookingList', nearby);
      } catch (_) {
        socket.emit('bookingList', []);
      }
    });
    // Driver responds to a booking
    socket.on('bookingResponse', async ({ passengerId, status, bookingId }) => {
      try {
        const { authenticateSocket } = require('./socketAuth');
        const { Booking } = require('../models/bookingModels');
        const user = await authenticateSocket(socket);
        if (!user || user.type !== 'driver') return;
        if (!bookingId || !status) return;
        const allowed = ['accepted','ongoing','completed','canceled'];
        if (!allowed.includes(String(status))) return;
        const b = await Booking.findById(bookingId);
        if (!b) return;
        b.status = status;
        await b.save();
        const latest = await Booking.find({}).sort({ createdAt: -1 }).limit(50).lean();
        io.emit('bookingList', latest.map(x => ({
          id: String(x._id),
          passengerId: x.passengerId,
          vehicleType: x.vehicleType,
          pickup: x.pickup,
          dropoff: x.dropoff,
          status: x.status,
          createdAt: x.createdAt,
          updatedAt: x.updatedAt
        })));
      } catch (_) {}
    });
    // Update driver location
    socket.on('updateLocation', async ({ lat, lng }) => {
      try {
        if (socket.data && socket.data.role === 'driver') {
          socket.data.location = { lat, lng };
          const { Driver } = require('../models/userModels');
          const { authenticateSocket } = require('./socketAuth');
          const user = await authenticateSocket(socket);
          if (user && user.type === 'driver') {
            await Driver.findByIdAndUpdate(user.id, { lastKnownLocation: { latitude: lat, longitude: lng } }).catch(() => {});
          }
        }
      } catch (_) {}
    });
    socket.on('driver:position', (payload) => {
      io.emit('driver:position', payload);
    });
    socket.on('pricing:update', (payload) => {
      io.emit('pricing:update', payload);
    });
    socket.on('disconnect', () => {
      // no-op
    });
  });
}

function broadcast(event, data) {
  if (ioRef) ioRef.emit(event, data);
}

function getIo() { return ioRef; }

module.exports = { attachSocketHandlers, broadcast, getIo };

